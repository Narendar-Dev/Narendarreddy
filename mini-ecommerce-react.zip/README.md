# Mini E-Commerce React App

A simple front-end e-commerce demo built with React.js to showcase UI skills.