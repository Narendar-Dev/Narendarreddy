import React from 'react';

function AdminPanel() {
  return (
    <div style={{ margin: '50px' }}>
      <h2>Welcome to the Admin Panel</h2>
      <p>This is a protected route visible only after login.</p>
    </div>
  );
}

export default AdminPanel;