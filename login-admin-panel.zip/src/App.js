import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Login from './components/Login';
import AdminPanel from './components/AdminPanel';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  return (
    <Routes>
      <Route path="/" element={<Login onLogin={() => setIsAuthenticated(true)} />} />
      <Route path="/admin" element={isAuthenticated ? <AdminPanel /> : <Navigate to="/" />} />
    </Routes>
  );
}

export default App;