# Login + Admin Panel UI

A simple React project with login functionality and a protected admin panel using React Router.